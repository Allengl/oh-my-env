class ApplicationMailer < ActionMailer::Base
  default from: "1942813644@qq.com"
  layout "mailer"
end
