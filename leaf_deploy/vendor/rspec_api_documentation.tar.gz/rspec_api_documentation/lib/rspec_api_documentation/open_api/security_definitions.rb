module RspecApiDocumentation
  module OpenApi
    class SecurityDefinitions < Node
      CHILD_CLASS = SecuritySchema
    end
  end
end
