module RspecApiDocumentation
  module OpenApi
    class Example < Node
      CHILD_CLASS = true
    end
  end
end
