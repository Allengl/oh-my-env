import{bE as e,bF as t,bV as o}from"./vendor.28e57c02.js";const p=e({props:{name:{type:String}},setup:(n,r)=>()=>t(o,null,null)});export{p as TagPage,p as default};
