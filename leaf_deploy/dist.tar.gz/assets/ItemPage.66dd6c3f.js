import{bE as e,bF as t,bV as o}from"./vendor.28e57c02.js";const a=e({props:{name:{type:String}},setup:(n,r)=>()=>t(o,null,null)});export{a as ItemPage,a as default};
